Vector3d v(1,2,3);
v.cwise() -= 5;
cout << v << endl;
