Vector3d v(3,2,4);
Vector3d w(5,4,2);
v.cwise() /= w;
cout << v << endl;
