Vector3d v(1,2,3);
v.cwise() += 3;
v.cwise() -= 2;
cout << v << endl;
