Matrix3i m = Matrix3i::Random();
cout << "Here is the matrix m:" << endl << m << endl;
cout << "Here is m.minor(1,1):" << endl << m.minor(1,1) << endl;
